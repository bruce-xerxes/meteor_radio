//###########################################################################
//  Bruce Van Deventer mod of TI demo code for UART and ADC
// This code reads an ADC channel and applies a 1KHZ bandpass filter
// it then squares and LPF averages the resulting signal, and then prints out
// a character representation of the envelope of the signal on the serial port
// or prints a period if the signal is below a threshold. Implemented on the
// TI Piccolo 28069 demo board, runs in Flash.
// FILE:   Example_2806xScia_Echoback.c
// - BV modified to include ADC function
// TITLE:  SCI Echo Back Example
//
//!  \addtogroup f2806x_example_list
//!  <h1>SCI Echo Back(sci_echoback)</h1>
//!
//!  This test receives and echo-backs data through the SCI-A port.
//!
//!  The PC application 'hypterterminal' can be used to view the data
//!  from the SCI and to send information to the SCI.  Characters received
//!  by the SCI port are sent back to the host.
//!
//!  \b Running \b the \b Application   
//!  -# Configure hyperterminal:
//!  Use the included hyperterminal configuration file SCI_96.ht.
//!  To load this configuration in hyperterminal
//!    -# Open hyperterminal
//!    -# Go to file->open
//!    -# Browse to the location of the project and
//!       select the SCI_96.ht file.
//!  -# Check the COM port.
//!  The configuration file is currently setup for COM1.
//!  If this is not correct, disconnect (Call->Disconnect)
//!  Open the File-Properties dialog and select the correct COM port.
//!  -# Connect hyperterminal Call->Call
//!  and then start the 2806x SCI echoback program execution.
//!  -# The program will print out a greeting and then ask you to
//!  enter a character which it will echo back to hyperterminal.
//!
//!  \note If you are unable to open the .ht file, you can create 
//!  a new one with the following settings
//!  -  Find correct COM port
//!  -  Bits per second = 9600
//!  -  Date Bits = 8
//!  -  Parity = None
//!  -  Stop Bits = 1
//!  -  Hardware Control = None
//!
//!  \b Watch \b Variables \n
//!  - \b LoopCount, for the number of characters sent
//!  - ErrorCount
//!
//! \b External \b Connections \n
//!  Connect the SCI-A port to a PC via a transceiver and cable.
//!  - GPIO28 is SCI_A-RXD (Connect to Pin3, PC-TX, of serial DB9 cable)
//!  - GPIO29 is SCI_A-TXD (Connect to Pin2, PC-RX, of serial DB9 cable)
//
//###########################################################################
// $TI Release:  $
// $Release Date:  $
// $Copyright:
// Copyright (C) 2009-2023 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################

//
// Included Files
//
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include <stdio.h>

//
// Function Prototypes
//
void scia_echoback_init(void);
void scia_fifo_init(void);
void scia_xmit(int a);
void scia_msg(char *msg);
 void init_buffers(void); // initialize IIR filter buffers
 void do_iir_filter(float); // prototype call to do the filter in the ISR
 void processbuffers(int); // processes the most recently filled filt_out1 or filt_out2 buffers
                             // and populates an integer entry in slowbuffer1 or 2
 void findmeteors(void);  // look thru slow buffers to find transition above and below thresh.

//
// Function Prototypes from ADC project
//
__interrupt void adc_isr(void);
void Adc_Config(void);

//
// Globals
// for Flash version
 extern Uint16 RamfuncsLoadStart;
 extern Uint16 RamfuncsLoadSize;
 extern Uint16 RamfuncsRunStart;
//
Uint16 LoopCount;
Uint16 ADCLoopCount; // from ADC
Uint16 ErrorCount;
Uint16 ConversionCount;  // from ADC
float Buffer1[80]; // input buffer 1
float Buffer2[80]; // input buffer 2
long slowbuffer[2][500]; // these are the FIR filter buffers which runs at 1/80 = 100ms so 5 seconds of samples

float v1[80]; // v is the intermediate node
float v2[80];
int buffer_pointer = 0; // where we are inside the current buffer
float filt_out1[80];
float filt_out2[80]; // these are the IIR filter outputs, which are buffered.
int which_buffer = 1; // which buffer is active
int last_buffer = 2; // previous buffer
int which_slow_buffer = 0;  // this can be 0 or 1
int slow_buffer_pointer = 0; // location IN the slow buffer

float mean = 800.0; // mean value tracker
float meansum = 0.0;

Uint16 Voltage1[80]; // from ADC
Uint16 Voltage2[80]; // from ADC


// const double b[5] = {
//   1.0, 0.0, -1.0, 0.0, 0.0 };     // 2nd order

// const double a[5] = {
//                   1.0,   -1.779276745,    0.92439049,   0.0,
//     0.0
// };
 // 1 KHZ IIR bandpass filter terms for direct form II, 950 to 1050Hz bandpass, fs=8KHz
// double b[5] = {0.001460316, 0.0, -0.0029206326, 0.0, 0.001460316}; //numerator
//  double a[5] = {1.0, -2.752083419, 3.78390742, -2.6032985839, 0.894874344 }; // denom
// this is a 900 to 1100 Hz version
double b[5] = { 0.00554271, 0.0, -0.011085434, 0.0, 0.0055427172 };
double a[5] = { 1.0, -2.6801581869, 3.57943442, -2.39757924, 0.8008026467 };
 //
 // 5Hz LPF IIR filter for 100Hz sampling, direct form II currently not used
 double bs[3] = { 1.0, 2.0, 1.0 };
 double as[3] = { 1.0, -1.142980502, 0.412801598 };
 double gain_slow = 0.06745;
// Main
//
void main(void)
{
    Uint16 ReceivedChar;
    char *msg;
    int result;


    //
    // Step 1. Initialize System Control:
    // PLL, WatchDog, enable Peripheral Clocks
    // This example function is found in the F2806x_SysCtrl.c file.
    //
    InitSysCtrl();

    //
    // Step 2. Initalize GPIO:
    // This example function is found in the F2806x_Gpio.c file and
    // illustrates how to set the GPIO to its default state.
    //
    //InitGpio(); Skipped for this example

    //
    // For this example, only init the pins for the SCI-A port.
    // This function is found in the F2806x_Sci.c file.
    //
    InitSciaGpio();

    //
    // Step 3. Clear all interrupts and initialize PIE vector table:
    // Disable CPU interrupts
    //
    DINT;

    //
    // Initialize PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    // This function is found in the F2806x_PieCtrl.c file.
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all CPU interrupt flags
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    // This will populate the entire table, even if the interrupt
    // is not used in this example.  This is useful for debug purposes.
    // The shell ISR routines are found in F2806x_DefaultIsr.c.
    // This function is found in F2806x_PieVect.c.
    //
    InitPieVectTable();
    // added InitFlash for run from flash
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (Uint32)&RamfuncsLoadSize);

    InitFlash();

    //
    // Step 4. Initialize all the Device Peripherals:
    // This function is found in F2806x_InitPeripherals.c
    //
    //InitPeripherals(); // Not required for this example
    EALLOW;  // This is needed to write to EALLOW protected register
    PieVectTable.ADCINT1 = &adc_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers
    //
    InitAdc();  // For this example, init the ADC
    AdcOffsetSelfCal();
    // Enable ADCINT1 in PIE
    //
    PieCtrlRegs.PIEIER1.bit.INTx1 = 1; // Enable INT 1.1 in the PIE
    IER |= M_INT1;                     // Enable CPU Interrupt 1
    EINT;                              // Enable Global interrupt INTM
    ERTM;                              // Enable Global realtime interrupt DBGM

    LoopCount = 0;
    ConversionCount = 0;

    //
    // Configure ADC
    //
    EALLOW;
    AdcRegs.ADCCTL2.bit.ADCNONOVERLAP = 1; // Enable non-overlap mode

    //
    // ADCINT1 trips after AdcResults latch
    //
    AdcRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    AdcRegs.INTSEL1N2.bit.INT1E     = 1;  // Enabled ADCINT1
    AdcRegs.INTSEL1N2.bit.INT1CONT  = 0;  // Disable ADCINT1 Continuous mode

    //
    // setup EOC1 to trigger ADCINT1 to fire
    //
    AdcRegs.INTSEL1N2.bit.INT1SEL   = 1;

    AdcRegs.ADCSOC0CTL.bit.CHSEL    = 4;  // set SOC0 channel select to ADCINA4
    AdcRegs.ADCSOC1CTL.bit.CHSEL    = 2;  // set SOC1 channel select to ADCINA2

    //
    // set SOC0 start trigger on EPWM1A, due to round-robin SOC0 converts
    // first then SOC1
    //
    AdcRegs.ADCSOC0CTL.bit.TRIGSEL  = 5;

    //
    // set SOC1 start trigger on EPWM1A, due to round-robin SOC0 converts
    // first then SOC1
    //
    AdcRegs.ADCSOC1CTL.bit.TRIGSEL  = 5;

    //
    // set SOC0 S/H Window to 7 ADC Clock Cycles, (6 ACQPS plus 1)
    //
    AdcRegs.ADCSOC0CTL.bit.ACQPS    = 6;

    //
    // set SOC1 S/H Window to 7 ADC Clock Cycles, (6 ACQPS plus 1)
    //
    AdcRegs.ADCSOC1CTL.bit.ACQPS    = 6;
    EDIS;

    //
    // Assumes ePWM1 clock is already enabled in InitSysCtrl();
    //
    EPwm1Regs.ETSEL.bit.SOCAEN  = 1;        // Enable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL = 4;        // Select SOC from CMPA on upcount
    EPwm1Regs.ETPS.bit.SOCAPRD  = 1;        // Generate pulse on 1st event
    EPwm1Regs.CMPA.half.CMPA    = 0x0080;   // Set compare A value
 //   EPwm1Regs.TBPRD             = 0xFFFF;   // Set period for ePWM1
    EPwm1Regs.TBPRD = 5625; // divisor ratio for 8KHz sampling if 90 mhz / 2 / 5625
    EPwm1Regs.TBCTL.bit.CTRMODE = 0;        // count up and start
    // Step 5. User specific code
    //
    LoopCount = 0;
    ErrorCount = 0;

    scia_fifo_init();	   // Initialize the SCI FIFO
    scia_echoback_init();  // Initalize SCI for echoback

    msg = "\r\n\n\nHello World!\0";
    scia_msg(msg);

    msg = "\r\nMeteor monitoring program \n\0";
    scia_msg(msg);

    for(;;)
    {
        msg = "\r\nEnter a character: \0";
        scia_msg(msg);

        //
        // Wait for inc character
        //
        while(SciaRegs.SCIFFRX.bit.RXFFST !=1)
        {
            //
            // wait for XRDY =1 for empty state do nothing here except poll for buffer swap
            //
         if (last_buffer == which_buffer) {
             // means we have switched buffers so process buffer because it's gonna switch
             processbuffers(which_buffer); // average the buffer and then step through the FIR filter

             if (which_buffer == 2) {
                 last_buffer=1;
             }
             else {
                 last_buffer=2;
             }

         } // if we just swapped buffers
        }

        //
        // Get character
        //
        ReceivedChar = SciaRegs.SCIRXBUF.all;

        //
        // Echo character back
        //
        msg = "  You: \0";
        scia_msg(msg);
        scia_xmit(ReceivedChar);
   //     result = sprintf(msg,"%d",Voltage1[1]);
        scia_msg(msg);
        LoopCount++;
        ConversionCount = 0; // reset ADC counter
    }
}

//
// scia_echoback_init - Test 1,SCIA  DLB, 8-bit word, baud rate 0x0103, 
// default, 1 STOP bit, no parity
//
void
scia_echoback_init()
{
    //
    // Note: Clocks were turned on to the SCIA peripheral
    // in the InitSysCtrl() function
    //
    
    //
    // 1 stop bit,  No loopback, No parity,8 char bits, async mode,
    // idle-line protocol
    //
    SciaRegs.SCICCR.all =0x0007;
    
    //
    // enable TX, RX, internal SCICLK, Disable RX ERR, SLEEP, TXWAKE
    //
    SciaRegs.SCICTL1.all =0x0003;

    SciaRegs.SCICTL2.bit.TXINTENA = 0;
    SciaRegs.SCICTL2.bit.RXBKINTENA = 0;

    //
    // 9600 baud @LSPCLK = 22.5MHz (90 MHz SYSCLK)
    //
    SciaRegs.SCIHBAUD    =0x0001;
    SciaRegs.SCILBAUD    =0x0024;

    SciaRegs.SCICTL1.all =0x0023;  // Relinquish SCI from Reset
}

//
// scia_xmit - Transmit a character from the SCI
//
void
scia_xmit(int a)
{
    while (SciaRegs.SCIFFTX.bit.TXFFST != 0)
    {
        
    }
    SciaRegs.SCITXBUF=a;
}

//
// scia_msg - 
//
void
scia_msg(char * msg)
{
    int i;
    i = 0;
    while(msg[i] != '\0')
    {
        scia_xmit(msg[i]);
        i++;
    }
}

//
// scia_fifo_init - Initalize the SCI FIFO
//
void
scia_fifo_init()
{
    SciaRegs.SCIFFTX.all=0xE040;
    SciaRegs.SCIFFRX.all=0x2044;
    SciaRegs.SCIFFCT.all=0x0;
}

//
//
// adc_isr -
//
__interrupt void
adc_isr(void)
{

   float temp_val;
    Voltage1[ConversionCount] = AdcResult.ADCRESULT0;
    Voltage2[ConversionCount] = AdcResult.ADCRESULT1;
    meansum = meansum + AdcResult.ADCRESULT0;
    // If 800 conversions have been logged, start over

    temp_val = (float) Voltage1[ConversionCount];
    temp_val = temp_val - mean;
    do_iir_filter(temp_val);
 // now manage end of buffers

    if(ConversionCount == 79)
    {
        ConversionCount = 0;
        mean = meansum/80.0; // calculate mean of averages when we swap buffers
        meansum = 0.0; // reset mean sum
        if(which_buffer == 1)
            {
            which_buffer = 2;
            }
            else
            {
            which_buffer = 1;
            }

    // conv count = 79
    }
    else
        {
        ConversionCount++;
        } // end if conv count == 79
    //
    // Clear ADCINT1 flag reinitialize for next SOC
    //
    AdcRegs.ADCINTFLGCLR.bit.ADCINT1 = 1;

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;   // Acknowledge interrupt to PIE

    return;
}
void init_buffers(void) {
    int i;
    for (i=0; i<80; i++) {
        Buffer1[i] = 0.0;
        Buffer2[i]= 0.0;
        v1[i] = 0.0;
        v2[i]=0.0;
        filt_out1[i]=0.0;
        filt_out2[i]=0.0;
    } // end for
    which_buffer=1;
    for (i=0; i<100; i++) {
        slowbuffer[1][i] = 0;
        slowbuffer[2][i] = 0;
        }// end for
    } // end init_buffers

void do_iir_filter(float temp_val) {
     int i;
    // implementer of IIR filter, called from exception table entry
    i= ConversionCount;
    if(which_buffer == 1) {
        Buffer1[i] = temp_val;

        switch(i) {
        case 0:
            v1[i] = (a[0]*Buffer1[0])-(a[1]*v2[79])-(a[2]*v2[78])-(a[3]*v2[77])-(a[4]*v2[76]);
            filt_out1[i] = (b[0]*v1[0])+(b[1]*v2[79])+(b[2]*v2[78])+(b[3]*v2[77])+(b[4]*v2[76]);
        break; // end case 0

        case 1:
            v1[i] = (a[0]*Buffer1[1])-(a[1]*v1[0])-(a[2]*v2[79])-(a[3]*v2[78])-(a[4]*v2[77]);
            filt_out1[i] = (b[0]*v1[1])+(b[1]*v1[0])+(b[2]*v2[79])+(b[3]*v2[78])+(b[4]*v2[77]);
        break; // end case 1

        case 2:
            v1[i] = (a[0]*Buffer1[2])-(a[1]*v1[1])-(a[2]*v1[0])-(a[3]*v2[79])-(a[4]*v2[78]);
            filt_out1[i] = (b[0]*v1[2])+(b[1]*v1[1])+(b[2]*v1[0])+(b[3]*v2[79])+(b[4]*v2[78]);
        break; // end case 2

        case 3:
            v1[i] = (a[0]*Buffer1[3])-(a[1]*v1[2])-(a[2]*v1[1])-(a[3]*v1[0])-(a[4]*v2[79]);
            filt_out1[i] = (b[0]*v1[3])+(b[1]*v1[2])+(b[2]*v1[1])+(b[3]*v1[0])+(b[4]*v2[79]);
        break; // end case 3

default:
    v1[i] = (a[0]*Buffer1[i])-(a[1]*v1[i-1])-(a[2]*v1[i-2])-(a[3]*v1[i-3])-(a[4]*v1[i-4]);
    filt_out1[i] = (b[0]*v1[i])+(b[1]*v1[i-1])+(b[2]*v1[i-2])+(b[3]*v1[i-3])+(b[4]*v1[i-4]);
break;
        } // end switch

    } // if buffer 1

    else // else we are buffer 2
    {
        Buffer2[i] = temp_val;

        switch(i) {
        case 0:
            v2[i] = (a[0]*Buffer2[0])-(a[1]*v1[79])-(a[2]*v1[78])-(a[3]*v1[77])-(a[4]*v1[76]);
            filt_out2[i] = (b[0]*v2[0])+(b[1]*v1[79])+(b[2]*v1[78])+(b[3]*v1[77])+(b[4]*v1[76]);
        break; // end case 0

        case 1:
            v2[i] = (a[0]*Buffer2[1])-(a[1]*v2[0])-(a[2]*v1[79])-(a[3]*v1[78])-(a[4]*v1[77]);
            filt_out2[i] = (b[0]*v2[1])+(b[1]*v2[0])+(b[2]*v1[79])+(b[3]*v1[78])+(b[4]*v1[77]);
        break; // end case 1

        case 2:
            v2[i] = (a[0]*Buffer2[2])-(a[1]*v2[1])-(a[2]*v2[0])-(a[3]*v1[79])-(a[4]*v1[78]);
            filt_out2[i] = (b[0]*v2[2])+(b[1]*v2[1])+(b[2]*v2[0])+(b[3]*v1[79])+(b[4]*v1[78]);
        break; // end case 2

        case 3:
            v2[i] = (a[0]*Buffer2[3])-(a[1]*v2[2])-(a[2]*v2[1])-(a[3]*v2[0])-(a[4]*v1[79]);
            filt_out2[i] = (b[0]*v2[3])+(b[1]*v2[2])+(b[2]*v2[1])+(b[3]*v2[0])+(b[4]*v1[79]);
        break; // end case 3
default:
    v2[i] = (a[0]*Buffer2[i])-(a[1]*v2[i-1])-(a[2]*v2[i-2])-(a[3]*v2[i-3])-(a[4]*v2[i-4]);
    filt_out2[i] = (b[0]*v2[i])+(b[1]*v2[i-1])+(b[2]*v2[i-2])+(b[3]*v2[i-3])+(b[4]*v2[i-4]);
    break;
        } // end switch i
    } // end if buffer 2
} // end do_iir_filter

void processbuffers(int which_buf) {
    // this routine has side effects to populate the slow buffers and update slow buffer pointer

    float temp_float;
    int i;

    temp_float = 0.0;
    for (i=0;i<80;i++) {
        if (which_buf==1) {
            temp_float = temp_float+(filt_out1[i]*filt_out1[i]);
        }
        else {
            temp_float = temp_float+(filt_out2[i]*filt_out2[i]);
        } // end if
    } // end for
     temp_float = temp_float/80.0;
     // now we do cheezy three sample square top moving average
     if (slow_buffer_pointer < 3) {
         slowbuffer[which_slow_buffer][slow_buffer_pointer] = (long)temp_float;
     }
     else
     {
         slowbuffer[which_slow_buffer][slow_buffer_pointer] = ((long)temp_float + slowbuffer[which_slow_buffer][slow_buffer_pointer-1] +
                 slowbuffer[which_slow_buffer][slow_buffer_pointer-2])/3;
     }
     slow_buffer_pointer++;
     if (slow_buffer_pointer == 500) {
         slow_buffer_pointer = 0;
         scia_xmit(46); // send a char to show we swapped slow buffers
         findmeteors(); // look for meteors in slow buffer
         if (which_slow_buffer == 0) {
             which_slow_buffer = 1;
         }
         else
         {
             which_slow_buffer = 0;
         }
     } // end if slow buffer pointer is 80
}
void findmeteors(void) {
    // find the signals greater than threshold in sample, must be greater than m_thresh for 3 samples
    static long m_thresh = 3000; // arbitrary counts, need to be tuned

    int m_toggle = 0; // false = no meteor
    int i;
    for (i=2;i<500;i++) {
        if ((slowbuffer[which_slow_buffer][i-2]> m_thresh) && (slowbuffer[which_slow_buffer][i-1] > m_thresh) && (slowbuffer[which_slow_buffer][i]>m_thresh))
        {
          if (m_toggle == 0) {
               scia_xmit(77); // send the character m at start of meteor
               m_toggle = -1; // make toggle true
           } // end if m_toggle
          scia_xmit(cheesynum(slowbuffer[which_slow_buffer][i])); // print 0-9 to print profile of meteor signal
        } // end if slowbuffer has three above thresh
        if ((m_toggle == -1) && (slowbuffer[which_slow_buffer][i] < m_thresh) && (slowbuffer[which_slow_buffer][i-1] < m_thresh)) {
            scia_xmit(78); // send N for end of meteor
            m_toggle = 0;
        } // end if
    } // end for
} // end subroutine

int cheesynum(long u ) {
    // this function returns an ASCII digit as hex 0 thru F for the signal strength u from 0 to 16000
    long temp_u;
    int temp_ans;
    temp_u = u/1000; // integer division
    if (temp_u < 0) temp_u = 0;
    if (temp_u > 15) temp_u = 15;
    temp_ans = (int) temp_u;
    temp_ans = temp_ans + 48; // ASCII offset to get to 0
    if (temp_ans > 57 ) temp_ans = temp_ans+ 7;
    return temp_ans;
}
    //


// End of File
//

